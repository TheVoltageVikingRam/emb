#define F_CPU 12000000UL  // Define the CPU clock frequency (12 MHz)

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	DDRA = 0x00;  // Set PORTA as input (no LEDs connected here)
	DDRB = 0xFF;  // Set PORTB as output (8 bits for LEDs)
	DDRC = 0xFB;  // Set PC2 as input (1111 1011)
	PORTC = 0xFF; // Enable pull-up resistors on PORTC
	PORTB = 0xAA; // Initialize PORTB (LED pattern)
	
	while(1)
	{
		if ((PINC & 0x04) == 0x04) // Check if button (PC2) is pressed
		{
			while((PINC & 0x04) == 0x04) // Wait until button is released
			{
				PORTB = PORTB; // Do nothing as long as button is pressed
			}
			PORTB ^= 0xFF; // Toggle LEDs on PORTB when button is released
		}
	}
}
